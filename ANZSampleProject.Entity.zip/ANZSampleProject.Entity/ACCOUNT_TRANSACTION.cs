namespace ANZSampleProject.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class ACCOUNT_TRANSACTION
    {
        [Key]
        public int TID { get; set; }

        public int ACCOUNT_ID { get; set; }

        [DisplayFormat(DataFormatString = "{0:MMM, dd, yyyy}")]
        [Column(TypeName = "date")]
        public DateTime VALUE_DATE { get; set; }

        [Required]
        [StringLength(3)]
        public string CURRENCY { get; set; }

        [Column(TypeName = "money")]
        public decimal AMOUNT { get; set; }

        [Required]
        [StringLength(10)]
        public string T_TYPE { get; set; }

        [StringLength(100)]
        public string T_NARRATIVE { get; set; }

        public virtual ACCOUNT ACCOUNT { get; set; }
        
    }
}
