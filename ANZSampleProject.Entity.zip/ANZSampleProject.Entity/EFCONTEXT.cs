namespace ANZSampleProject.Entity
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class EFCONTEXT : DbContext
    {
        public EFCONTEXT()
            : base("name=EFCONTEXT")
        {
        }

        public virtual DbSet<ACCOUNT> ACCOUNTs { get; set; }
        public virtual DbSet<ACCOUNT_TRANSACTION> ACCOUNT_TRANSACTION { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ACCOUNT>()
                .Property(e => e.USER_NAME)
                .IsUnicode(false);

            modelBuilder.Entity<ACCOUNT>()
                .Property(e => e.ACCOUNT_NAME)
                .IsUnicode(false);

            modelBuilder.Entity<ACCOUNT>()
                .Property(e => e.ACCOUNT_TYPE)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<ACCOUNT>()
                .Property(e => e.CURRENCY)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<ACCOUNT>()
                .Property(e => e.OPEN_AVL_BAL)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ACCOUNT>()
                .HasMany(e => e.ACCOUNT_TRANSACTION)
                .WithRequired(e => e.ACCOUNT)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ACCOUNT_TRANSACTION>()
                .Property(e => e.CURRENCY)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<ACCOUNT_TRANSACTION>()
                .Property(e => e.AMOUNT)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ACCOUNT_TRANSACTION>()
                .Property(e => e.T_TYPE)
                .IsFixedLength()
                .IsUnicode(false);
         
        }
    }
}
