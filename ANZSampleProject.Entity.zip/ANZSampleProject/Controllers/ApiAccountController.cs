﻿using ANZSampleProject.Entity;
using System.Data;
using System.Linq;
using System.Web.Http;

namespace ANZSampleProject.Controllers
{
    public class ApiAccountController : ApiController
    {
        private EFCONTEXT db = new EFCONTEXT();
        // Get UserName from Session
        private readonly string UserName = "user1";
        // GET: api/ApiAccount
        public IQueryable<ACCOUNT> GetACCOUNTs()
        {
            db.Configuration.ProxyCreationEnabled = false;
            return db.ACCOUNTs.Where(x=>x.USER_NAME== UserName).OrderByDescending(x => x.BAL_DATE);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}