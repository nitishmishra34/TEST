﻿using ANZSampleProject.Entity;
using System.Data;
using System.Linq;
using System.Web.Http;

namespace ANZSampleProject.Controllers
{
    public class ApiAccountTransactionController : ApiController
    {
        private EFCONTEXT db = new EFCONTEXT();
        // Get UserName from Session
        private readonly string UserName = "user1";

        // GET: api/ApiAccountTransaction?AccountId=1       
        public IQueryable<ACCOUNT_TRANSACTION> GetACCOUNT_TRANSACTION(int AccountId)
        {
            db.Configuration.ProxyCreationEnabled = false;
            return db.ACCOUNT_TRANSACTION.Include("ACCOUNT").Where(x => x.ACCOUNT_ID == AccountId && x.ACCOUNT.USER_NAME == UserName).OrderByDescending(y=>y.VALUE_DATE);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}